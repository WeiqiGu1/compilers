package babycino;

// An exception thrown by the compiler, signalling a fatal error.
public class CompilerException extends Exception {
}

