class TestBugE {
    public static void main(String[] a) {
	if (new Test().f()) {System.out.println(1);} else {System.out.println(0);}
    }
}

class Test {

    public boolean f() {
	int x;
	int y;
	boolean result;
	boolean c;
	x = 5;
	y = 3;
        //result = x > y;// should print 1
	//result = y > x;// should print 0
	result = y > c;// should have error message

	return result;
    }
}
