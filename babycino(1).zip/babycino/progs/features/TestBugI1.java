class TestBugI1 {
    public static void main(String[] args) {
	System.out.println(new Test().f());
    }
}

class Test {

    public int f() {
        boolean x;
        x = true;
        x++; // Bug I1: Incrementing a boolean variable
	return x;
}
}
