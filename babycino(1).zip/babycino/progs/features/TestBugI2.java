class TestBugI2 {
    public static void main(String[] args) {
	System.out.println(new Test().f());
    }
}

class Test {

    public int f() {
        int x;
        x = 0;
        x++; // Bug I2: Setting x to 1 instead of incrementing
	return x;
}
}
