class TestBugI3 {
    public static void main(String[] args) {
        int x;
        x = 5;
        x++; // Bug I3: Not modifying x at all
        System.out.println(x);
    }
}
