class MinimalClass {
    public static void main(String[] args) {
        {
        }
    }
}

class Empty {

}

