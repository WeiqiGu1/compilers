#!/bin/sh
exec java -cp .:contrib/antlr/antlr-4.9.1-complete.jar org.antlr.v4.gui.TestRig "$@"

